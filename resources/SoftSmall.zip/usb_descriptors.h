#ifndef _USB_DESCRIPTORS_H_
#define _USB_DESCRIPTORS_H_

//_____ I N C L U D E S ____________________________________________________

#include "config.h"
#include "usb_standard_request.h"
#include "conf_usb.h"

//_____ M A C R O S ________________________________________________________

#define Usb_get_dev_desc_pointer()        (&(usb_dev_desc.bLength))
#define Usb_get_dev_desc_length()         (sizeof (usb_dev_desc))
#define Usb_get_conf_desc_pointer()       (&(usb_conf_desc.cfg_desc.bLength))
#define Usb_get_conf_desc_length()        (sizeof (usb_conf_desc))

//_____ U S B    D E F I N E _______________________________________________

// USB Device descriptor
#define USB_SPECIFICATION     0x0200
#define DEVICE_CLASS          0      // each configuration has its own class
#define DEVICE_SUB_CLASS      0      // each configuration has its own sub-class
#define DEVICE_PROTOCOL       0      // each configuration has its own protocol
#define EP_CONTROL_LENGTH     64
#define VENDOR_ID             VID_ATMEL
#define PRODUCT_ID            0xff01
#define RELEASE_NUMBER        0x1000
#define MAN_INDEX             0x01
#define PROD_INDEX            0x02   
#if (USB_DEVICE_SN_USE==ENABLE)
#define SN_INDEX              0x03
#else
#define SN_INDEX              0x00  // No serial number field
#endif
#define NB_CONFIGURATION      1

// CONFIGURATION
#define NB_INTERFACE       1           // Number of interfaces
#define CONF_NB            1
#define CONF_INDEX         0
#define CONF_ATTRIBUTES    USB_CONFIG_BUSPOWERED
#define MAX_POWER          450/2          // 100 mA

// USB Interface descriptor
#define INTERFACE_NB        0          // Interface's number
#define ALTERNATE           0
#define NB_ENDPOINT         0
#define INTERFACE_CLASS     CLASS_VENDOR     // 
#define INTERFACE_SUB_CLASS NO_SUBCLASS
#define INTERFACE_PROTOCOL  NO_PROTOCOL
#define INTERFACE_INDEX     0
/*
// USB Endpoint 1 descriptor FS
#define ENDPOINT_NB_1       (EP_IN | USB_ENDPOINT_IN)
#define EP_ATTRIBUTES_1     0x02          // BULK = 0x02, INTERUPT = 0x03
#define EP_IN_LENGTH        256
#define EP_SIZE_1           EP_IN_LENGTH
#define EP_INTERVAL_1       0x00          


// USB Endpoint 2 descriptor FS
#define ENDPOINT_NB_2       EP_OUT
#define EP_ATTRIBUTES_2     0x02          // BULK = 0x02, INTERUPT = 0x03
#define EP_IN_LENGTH        64
#define EP_SIZE_2           EP_IN_LENGTH
#define EP_INTERVAL_2       0x00          
*/
#define DEVICE_STATUS         USB_DEVICE_STATUS_BUS_POWERED

#define LANG_ID               0x00

#define USB_MN_LENGTH         3
#define USB_MANUFACTURER_NAME \
	{ Usb_unicode('S') \
	, Usb_unicode('P') \
	, Usb_unicode('M') \
}

#define USB_PN_LENGTH         5
#define USB_PRODUCT_NAME \
	{ Usb_unicode('S') \
	,Usb_unicode('C') \
	,Usb_unicode('R') \
	,Usb_unicode('U') \
	,Usb_unicode('T') \
}

#define LANGUAGE_ID           0x0409

//! Usb Request
typedef struct
{
	U8      bmRequestType;        //!< Characteristics of the request
	U8      bRequest;             //!< Specific request
	U16     wValue;               //!< field that varies according to request
	U16     wIndex;               //!< field that varies according to request
	U16     wLength;              //!< Number of bytes to transfer if Data
}  S_UsbRequest;

//! Usb Device Descriptor
typedef struct {
	U8      bLength;              //!< Size of this descriptor in bytes
	U8      bDescriptorType;      //!< DEVICE descriptor type
	U16     bscUSB;               //!< Binay Coded Decimal Spec. release
	U8      bDeviceClass;         //!< Class code assigned by the USB
	U8      bDeviceSubClass;      //!< Sub-class code assigned by the USB
	U8      bDeviceProtocol;      //!< Protocol code assigned by the USB
	U8      bMaxPacketSize0;      //!< Max packet size for EP0
	U16     idVendor;             //!< Vendor ID. ATMEL = 0x03EB
	U16     idProduct;            //!< Product ID assigned by the manufacturer
	U16     bcdDevice;            //!< Device release number
	U8      iManufacturer;        //!< Index of manu. string descriptor
	U8      iProduct;             //!< Index of prod. string descriptor
	U8      iSerialNumber;        //!< Index of S.N.  string descriptor
	U8      bNumConfigurations;   //!< Number of possible configurations
}  S_usb_device_descriptor;

//! Usb Configuration Descriptor
typedef struct {
	U8      bLength;              //!< size of this descriptor in bytes
	U8      bDescriptorType;      //!< CONFIGURATION descriptor type
	U16     wTotalLength;         //!< total length of data returned
	U8      bNumInterfaces;       //!< number of interfaces for this conf.
	U8      bConfigurationValue;  //!< value for SetConfiguration resquest
	U8      iConfiguration;       //!< index of string descriptor
	U8      bmAttibutes;          //!< Configuration characteristics
	U8      MaxPower;             //!< maximum power consumption
}  S_usb_configuration_descriptor;

//! Usb Interface Descriptor
typedef struct {
	U8      bLength;               //!< size of this descriptor in bytes
	U8      bDescriptorType;       //!< INTERFACE descriptor type
	U8      bInterfaceNumber;      //!< Number of interface
	U8      bAlternateSetting;     //!< value to select alternate setting
	U8      bNumEndpoints;         //!< Number of EP except EP 0
	U8      bInterfaceClass;       //!< Class code assigned by the USB
	U8      bInterfaceSubClass;    //!< Sub-class code assigned by the USB
	U8      bInterfaceProtocol;    //!< Protocol code assigned by the USB
	U8      iInterface;            //!< Index of string descriptor
}  S_usb_interface_descriptor;

//! Usb Endpoint Descriptor
typedef struct {
	U8      bLength;               //!< Size of this descriptor in bytes
	U8      bDescriptorType;       //!< ENDPOINT descriptor type
	U8      bEndpointAddress;      //!< Address of the endpoint
	U8      bmAttributes;          //!< Endpoint's attributes
	U16     wMaxPacketSize;        //!< Maximum packet size for this EP
	U8      bInterval;             //!< Interval for polling EP in ms
} S_usb_endpoint_descriptor;

//! Usb Language Descriptor
typedef struct {
	U8      bLength;               //!< size of this descriptor in bytes
	U8      bDescriptorType;       //!< STRING descriptor type
	U16     wlangid;               //!< language id
}  S_usb_language_id;

//struct usb_st_manufacturer
typedef struct {
	U8  bLength;               // size of this descriptor in bytes
	U8  bDescriptorType;       // STRING descriptor type
	U16 wstring[USB_MN_LENGTH];// unicode characters
} S_usb_manufacturer_string_descriptor;

//struct usb_st_product
typedef struct {
	U8  bLength;               // size of this descriptor in bytes
	U8  bDescriptorType;       // STRING descriptor type
	U16 wstring[USB_PN_LENGTH];// unicode characters
} S_usb_product_string_descriptor;

typedef struct
{
	S_usb_configuration_descriptor cfg_desc;
	S_usb_interface_descriptor     ifc_desc;
	S_usb_endpoint_descriptor      ep_in_desc;
} S_usb_user_configuration_descriptor;

#endif

