#ifndef _USB_TASK_H_
#define _USB_TASK_H_

#include "usb_commun.h"

//! @defgroup usb_software_evts USB software Events Management
//! Macros to manage USB events detected under interrupt
//! @{
#define Usb_send_event(x)               (g_usb_event |= (1<<x))
#define Usb_ack_event(x)                (g_usb_event &= ~(1<<x))
#define Usb_clear_all_event()           (g_usb_event = 0)
#define Is_usb_event(x)                 ((g_usb_event & (1<<x)) ? TRUE : FALSE)
#define Is_not_usb_event(x)             ((g_usb_event & (1<<x)) ? FALSE: TRUE)
#define Is_host_emergency_exit()        (Is_usb_id_device())

#define EVT_USB_POWERED               1         // USB plugged
#define EVT_USB_UNPOWERED             2         // USB un-plugged
#define EVT_USB_DEVICE_FUNCTION       3         // USB in device
#define EVT_USB_HOST_FUNCTION         4         // USB in host
#define EVT_USB_SUSPEND               5         // USB suspend
#define EVT_USB_WAKE_UP               6         // USB wake up
#define EVT_USB_RESUME                7         // USB resume
#define EVT_USB_RESET                 8         // USB reset

extern volatile U16 g_usb_event;

/**
* @brief This function initializes the USB proces.
*
*  This function enables the USB controller and init the USB interrupts.
*  The aim is to allow the USB connection detection in order to send
*  the appropriate USB event to the operating mode manager.
*  Depending on the mode supported (HOST/DEVICE/DUAL_ROLE) the function
*  calls the corespong usb mode initialization function
*
*  @param none
*
*  @return none
*/
void usb_task_init     (void);

/**
*  @brief Entry point of the USB mamnagement
*
*  Depending on the mode supported (HOST/DEVICE/DUAL_ROLE) the function
*  calls the corespong usb management function
*
*  @param none
*
*  @return none
*/
void usb_task          (void);

#endif /* _USB_TASK_H_ */

