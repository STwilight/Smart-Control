#include "packet.h"
#include "config.h"
#include "conf_usb.h"
#include "usb_drv.h"
#include "usb_descriptors.h"
#include "usb_standard_request.h"
#include "usb_specific_request.h"

//_____ D E F I N I T I O N ________________________________________________

bit  ms_multiple_drive;

extern U8   code *pbuffer;
extern U8   data_to_transfer;
U16		State;
U16		LastError;

//_____ D E C L A R A T I O N ______________________________________________

//! @breif This function checks the specific request and if known then processes it
//!
//! @param type      corresponding at bmRequestType (see USB specification)
//! @param request   corresponding at bRequest (see USB specification)
//!
//! @return TRUE,  when the request is processed
//! @return FALSE, if the request is'nt know (STALL handshake is managed by the main standard request function).
//!
Bool usb_user_read_request(U8 type, U8 request)
{
	U16	i,j;
	U16 wLength;
	U8 dummy;
			PORTC = 0x4;	// Red
	
	// Read wValue
	dummy = Usb_read_byte();		// wValue
	dummy = Usb_read_byte();
	dummy = Usb_read_byte();		// wIndex
	dummy = Usb_read_byte();
	LSB(wLength) = Usb_read_byte();	// wLength
	MSB(wLength) = Usb_read_byte();
	
	if( USB_SETUP_SET_VENDOR_INTERFACE == type )
	{
		switch( request )
		{
		case DEV_WRITE:
			Usb_ack_receive_setup();
			i = 30000;
			while(!Is_usb_receive_out()) if(!--i) goto ERR;
			for(i=0; i<64; i++)
				dummy = Usb_read_byte();
			Usb_ack_control_out();
			i = 30000;
			while(!Is_usb_receive_out()) if(!--i) goto ERR;
			for(i=0; i<64; i++)
				dummy = Usb_read_byte();
			Usb_ack_control_out();
			Usb_send_control_in();
			return TRUE;

		case DEV_READ:
		case DEV_REQREAD:
			Usb_ack_control_out();
			Usb_ack_receive_setup();
			Usb_send_control_in();
			return TRUE;
		}
	}
	if( USB_SETUP_GET_VENDOR_INTERFACE == type )
	{
		switch( request )
		{
		case DEV_ID:
			Usb_ack_receive_setup();
			Usb_write_byte(0);	// ����� ����������
			Usb_write_byte(0);
			Usb_write_byte(0);	// ��� ����������
			Usb_write_byte(0);
			Usb_write_byte(0);	// ������ L
			Usb_write_byte(1);	// H
			goto SendACK;

		case DEV_READ:
			Usb_ack_receive_setup();
			j = 0;
			for(;;)
			{
				i = 30000;
				while(!Is_usb_read_control_enabled()) if(!--i) goto ERR;
				for(i=0; i<32; i++, j++)
				{
					Usb_write_byte(LSB(j));
					if(--wLength <= 0) goto end;
					Usb_write_byte(MSB(j));
					if(--wLength <= 0) goto end;
				}
				Usb_send_control_in();
			}
		end:
			goto SendACK;

		case DEV_WRITE:
			Usb_ack_receive_setup();
			goto ACK;

		case DEV_STATUS:
			Usb_ack_receive_setup();
			Usb_write_byte(LSB(State));
			Usb_write_byte(MSB(State));
			Usb_write_byte(LSB(LastError));
			Usb_write_byte(MSB(LastError));
			goto SendACK;

		case DEV_RESET:
			Usb_ack_receive_setup();
			goto ACK;
		}
	}
	return FALSE;  // No supported request

SendACK:
	Usb_send_control_in();
ACK:
	i=3000;
	while( !Is_usb_receive_out() ) if(!--i) goto ERR;
	Usb_ack_control_out();
	return TRUE;
ERR:
	return FALSE;
}

//! @brief This function configures the endpoints
//!
//! @param conf_nb configuration number choosed by USB host
//!
/*void usb_user_endpoint_init(U8 conf_nb)
{
	usb_configure_endpoint(EP_IN,      \
		TYPE_BULK,     \
		DIRECTION_IN,  \
		SIZE_256,       \
		TWO_BANKS,     \
		NYET_ENABLED);
}
*/

//! @brief This function returns the interface alternate setting
//!
//! @param wInterface         Interface selected
//!
//! @return alternate setting configurated
//!
U8   usb_user_interface_get( U16 wInterface )
{
	return 0;  // Only one alternate setting possible for all interface
}

//! @brief This function selects (and resets) the interface alternate setting
//!
//! @param wInterface         Interface selected
//! @param alternate_setting  alternate setting selected
//!
void usb_user_interface_reset(U16 wInterface, U8 alternate_setting)
{  
	// default setting selected = reset data toggle
	if( INTERFACE_NB == wInterface )
	{
//		Usb_select_endpoint(EP_IN);
//		Usb_disable_stall_handshake();
//		Usb_reset_endpoint(EP_IN);
		Usb_reset_data_toggle();
	}
}


//! This function fills the global descriptor
//!
//! @param type      corresponding at MSB of wValue (see USB specification)
//! @param string    corresponding at LSB of wValue (see USB specification)
//!
//! @return FALSE, if the global descriptor no filled
//!
Bool usb_user_get_descriptor(U8 type, U8 string)
{
	switch(type)
	{
	case DESCRIPTOR_STRING:
		switch (string)
		{
		case LANG_ID:
			data_to_transfer = sizeof (usb_user_language_id);
			pbuffer = &(usb_user_language_id.bLength);
			return TRUE;
			
		case MAN_INDEX:
			data_to_transfer = sizeof (usb_user_manufacturer_string_descriptor);
			pbuffer = &(usb_user_manufacturer_string_descriptor.bLength);
			return TRUE;
			
		case PROD_INDEX:
			data_to_transfer = sizeof (usb_user_product_string_descriptor);
			pbuffer = &(usb_user_product_string_descriptor.bLength);
			return TRUE;
		}
		break;
	}
	return FALSE;
}
