#include "config.h"
#include "conf_usb.h"

#include "usb_drv.h"
#include "usb_descriptors.h"
#include "usb_standard_request.h"
#include "usb_specific_request.h"
#if ((USB_DEVICE_SN_USE==ENABLE) && (USE_DEVICE_SN_UNIQUE==ENABLE))
#include "flash_drv.h"
#endif

// usb_user_device_descriptor
code S_usb_device_descriptor usb_dev_desc =
{
	sizeof(usb_dev_desc)
		, DESCRIPTOR_DEVICE
		, Usb_write_word_enum_struc(USB_SPECIFICATION)
		, DEVICE_CLASS
		, DEVICE_SUB_CLASS
		, DEVICE_PROTOCOL
		, EP_CONTROL_LENGTH
		, Usb_write_word_enum_struc(VENDOR_ID)
		, Usb_write_word_enum_struc(PRODUCT_ID)
		, Usb_write_word_enum_struc(RELEASE_NUMBER)
		, MAN_INDEX
		, PROD_INDEX
		, SN_INDEX
		, NB_CONFIGURATION
};

// usb_user_configuration_descriptor FS
code S_usb_user_configuration_descriptor usb_conf_desc = {
	{ sizeof(S_usb_configuration_descriptor)
		, DESCRIPTOR_CONFIGURATION
		, Usb_write_word_enum_struc(sizeof(S_usb_configuration_descriptor)\
		+sizeof(S_usb_interface_descriptor))
		, NB_INTERFACE
		, CONF_NB
		, CONF_INDEX
		, CONF_ATTRIBUTES
		, MAX_POWER
	}
	,
	{ sizeof(S_usb_interface_descriptor)
		, DESCRIPTOR_INTERFACE
		, INTERFACE_NB
		, ALTERNATE
		, NB_ENDPOINT
		, INTERFACE_CLASS
		, INTERFACE_SUB_CLASS
		, INTERFACE_PROTOCOL
		, INTERFACE_INDEX
	}
};

// usb_user_manufacturer_string_descriptor
code S_usb_manufacturer_string_descriptor usb_user_manufacturer_string_descriptor = {
	sizeof(usb_user_manufacturer_string_descriptor)
	, DESCRIPTOR_STRING
	, USB_MANUFACTURER_NAME
};

// usb_user_product_string_descriptor
code S_usb_product_string_descriptor usb_user_product_string_descriptor = {
	sizeof(usb_user_product_string_descriptor)
	, DESCRIPTOR_STRING
	, USB_PRODUCT_NAME
};

// usb_user_language_id
code S_usb_language_id usb_user_language_id = {
	sizeof(usb_user_language_id)
	, DESCRIPTOR_STRING
	, Usb_write_word_enum_struc(LANGUAGE_ID)
};
