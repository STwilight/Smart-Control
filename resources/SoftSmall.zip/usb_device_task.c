#include "config.h"
#include "conf_usb.h"
#include "usb_device_task.h"
#include "usb_task.h"
#include "usb_drv.h"
#include "usb_descriptors.h"
#include "usb_standard_request.h"
#include "pll_drv.h"

//! Public : (bit) usb_connected
//! usb_connected is set to TRUE when VBUS has been detected
//! usb_connected is set to FALSE otherwise
bit   usb_connected=FALSE;

//! Public : (bit) usb_suspended
//! usb_suspended is set to TRUE when USB is in suspend mode
//! usb_suspended is set to FALSE otherwise
bit   usb_suspended=FALSE;

//! Public : (U8) usb_configuration_nb
//! Store the number of the USB configuration used by the USB device
//! when its value is different from zero, it means the device mode is enumerated
extern U8  usb_configuration_nb;

//! @brief This function initializes the USB device controller and system interrupt
//!
//! This function enables the USB controller and init the USB interrupts.
//! The aim is to allow the USB connection detection in order to send
//! the appropriate USB event to the operating mode manager.
void usb_device_task_init(void)
{
	Usb_disable();
	Usb_enable();
}

//! This function enables the USB controller and init the USB interrupts.
//! The aim is to allow the USB connection detection in order to send
//! the appropriate USB event to the operating mode manager.
//! Start device function is executed once VBUS connection has been detected
//! either by the VBUS change interrupt either by the VBUS high level
void usb_start_device (void)
{
	Usb_freeze_clock();
	Pll_start_auto();
	Wait_pll_ready();
	Usb_unfreeze_clock();
	Usb_attach();
	Usb_reset_macro_only();
	usb_init_device();         // configure the USB controller EP0
	Usb_enable_suspend_interrupt();
	Usb_enable_reset_interrupt();
	Enable_interrupt();
}

//! This function is the entry point of the USB management. Each USB
//! event is checked here in order to launch the appropriate action.
//! If a Setup request occurs on the Default Control Endpoint,
//! the usb_process_request() function is call in the usb_standard_request.c file
void usb_device_task(void)
{
	if (usb_connected == FALSE)
	{
		usb_connected = TRUE;    // attach if application is not self-powered
		usb_start_device();
		Usb_vbus_on_action();
	}
	
	if(Is_usb_event(EVT_USB_RESET))
	{
		Usb_ack_event(EVT_USB_RESET);
		Usb_reset_endpoint(0);
		usb_configuration_nb=0;
	}
	
	// =======================================
	// Common Standard Device Control Requests
	// =======================================
	//   - device enumeration process
	//   - device control commands and features
	Usb_select_endpoint(EP_CONTROL);
	if (Is_usb_receive_setup())
	{
		usb_process_request();
	}
}
