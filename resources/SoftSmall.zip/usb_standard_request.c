#include "config.h"
#include "conf_usb.h"
#include "usb_drv.h"
#include "usb_descriptors.h"
#include "usb_standard_request.h"
#include "usb_specific_request.h"
#include "pll_drv.h"

static   Bool  usb_get_descriptor   ( void );
static   void  usb_set_address      ( void );
static   Bool  usb_set_configuration( void );
static   void  usb_get_configuration( void );
static   Bool  usb_get_status       ( U8 bmRequestType );
static   Bool  usb_set_feature      ( U8 bmRequestType );
static   Bool  usb_clear_feature    ( U8 bmRequestType );
static   Bool  usb_get_interface    ( void );
static   Bool  usb_set_interface    ( void );

#ifndef USB_REMOTE_WAKEUP_FEATURE
#error USB_REMOTE_WAKEUP_FEATURE should be defined as ENABLE or DISABLE in conf_usb.h
#endif

U8   code *pbuffer;
#define Usb_write_PGM_byte(byte) (Usb_write_byte(*byte))

U8    endpoint_status[MAX_EP_NB];
U8    data_to_transfer;
U8    usb_configuration_nb;
U8    remote_wakeup_feature = DISABLE; 
U8    device_status = DEVICE_STATUS;

//! @brief This function reads the SETUP request sent to the default control endpoint
//! and calls the appropriate function. When exiting of the usb_read_request
//! function, the device is ready to manage the next request.
//!
void usb_process_request(void)
{
	U8 bmRequestType;
	U8 bmRequest;
	
	Usb_ack_control_out();
	bmRequestType = Usb_read_byte();
	bmRequest     = Usb_read_byte();
	
	switch (bmRequest)
	{
	case SETUP_GET_DESCRIPTOR:
		if (USB_SETUP_GET_STAND_DEVICE == bmRequestType)
		{     
			if( usb_get_descriptor() )
				return;
		}
		break;
		
	case SETUP_GET_CONFIGURATION:
		if (USB_SETUP_GET_STAND_DEVICE == bmRequestType)
		{
			usb_get_configuration();
			return;
		}
		break;
		
	case SETUP_SET_ADDRESS:
		if (USB_SETUP_SET_STAND_DEVICE == bmRequestType)
		{
			usb_set_address();
			return;
		}
		break;
		
	case SETUP_SET_CONFIGURATION:
		if (USB_SETUP_SET_STAND_DEVICE == bmRequestType)
		{ 
			if( usb_set_configuration() )
				return;
		}
		break;
		
	case SETUP_CLEAR_FEATURE:
		if (USB_SETUP_GET_STAND == (bmRequestType & USB_SETUP_RECIPIENT_MASK))
		{
			if (usb_clear_feature(bmRequestType))
				return;
		}
		break;
		
	case SETUP_SET_FEATURE:
		if (USB_SETUP_GET_STAND == (bmRequestType & USB_SETUP_RECIPIENT_MASK))
		{
			if (usb_set_feature(bmRequestType))
				return;
		}
		break;
		
	case SETUP_GET_STATUS:
		if (USB_SETUP_GET_STAND == (bmRequestType & USB_SETUP_RECIPIENT_MASK))
		{
			if (usb_get_status(bmRequestType))
				return;
		}
		break;
		
	case SETUP_GET_INTERFACE:
		if (USB_SETUP_GET_STAND_INTERFACE == bmRequestType)
		{
			if( usb_get_interface() )
				return;
		}
		break;
		
	case SETUP_SET_INTERFACE:
		if (bmRequestType == USB_SETUP_SET_STAND_INTERFACE)
		{
			if( usb_set_interface() )
				return;
		}
		break;
		
	default:
		break;
	}
	
	// un-supported like standard request => call to user read request
	if( !usb_user_read_request(bmRequestType, bmRequest) )
	{
		// Request unknow in the specific request list from interface
		// keep that order (set StallRq/clear RxSetup) or a
		// OUT request following the SETUP may be acknowledged
		Usb_enable_stall_handshake();
		Usb_ack_receive_setup();
		endpoint_status[(EP_CONTROL & MSK_EP_DIR)] = 0x01;
	}
}

//! This function manages the SET ADDRESS request. When complete, the device
//! will filter the requests using the new address.
//!
void usb_set_address(void)
{
	U8 addr = Usb_read_byte();
	Usb_configure_address(addr);
	
	Usb_ack_receive_setup();
	
	Usb_send_control_in();                    // send a ZLP for STATUS phase
	while(!Is_usb_in_ready());                // waits for status phase done
	// before using the new address
	Usb_enable_address();
}

//! This function manages the SET CONFIGURATION request. If the selected
//! configuration is valid, this function call the usb_user_endpoint_init()
//! function that will configure the endpoints following the configuration
//! number.
//!
Bool usb_set_configuration( void )
{
	U8 configuration_number;
	
	// Get/Check new configuration
	configuration_number = Usb_read_byte();
	if (configuration_number > NB_CONFIGURATION)
		return FALSE;  //  Bad configuration number then stall request
	Usb_ack_receive_setup();
	usb_configuration_nb = configuration_number;
	
	Usb_send_control_in();                          // send a ZLP for STATUS phase
	Usb_set_configuration_action();
	return TRUE;
}

//! This function manages the GET DESCRIPTOR request. The device descriptor,
//! the configuration descriptor and the device qualifier are supported. All
//! other descriptors must be supported by the usb_user_get_descriptor
//! function.
//! Only 1 configuration is supported.
//!
Bool usb_get_descriptor(void)
{
	Bool zlp;
	U16  wLength;
	U8   descriptor_type ;
	U8   string_type;
	U8   dummy;
	U8   nb_byte;
    
	zlp             = FALSE;                  /* no zero length packet */
	string_type     = Usb_read_byte();        /* read LSB of wValue    */
	descriptor_type = Usb_read_byte();        /* read MSB of wValue    */
	
	switch (descriptor_type)
	{
	case DESCRIPTOR_DEVICE:
		data_to_transfer = Usb_get_dev_desc_length(); //!< sizeof (usb_user_device_descriptor);
		pbuffer          = Usb_get_dev_desc_pointer();
		break;
		
	case DESCRIPTOR_CONFIGURATION:
		data_to_transfer = Usb_get_conf_desc_length(); //!< sizeof (usb_user_configuration_descriptor);
		pbuffer          = Usb_get_conf_desc_pointer();
		break;
		
	default:
		if( !usb_user_get_descriptor(descriptor_type, string_type))
			return FALSE;  // Unknow descriptor then stall request
		break;
	}
	
	dummy = Usb_read_byte();                     //!< don't care of wIndex field
	dummy = Usb_read_byte();
	LSB(wLength) = Usb_read_byte();              //!< read wLength
	MSB(wLength) = Usb_read_byte();
	Usb_ack_receive_setup() ;                  //!< clear the receive setup flag
	
	if (wLength > data_to_transfer)
	{
		if ((data_to_transfer % EP_CONTROL_LENGTH) == 0) { zlp = TRUE; }
		else { zlp = FALSE; }                   //!< no need of zero length packet
	}
	else
	{
		data_to_transfer = (U8)wLength;		//!< send only requested number of data
	}
	
	Usb_ack_nak_out();
    
	while((data_to_transfer != 0) && (!Is_usb_nak_out_sent()))
	{
		while(!Is_usb_read_control_enabled())
		{
			if (Is_usb_nak_out_sent())
				break;    // don't clear the flag now, it will be cleared after
		}
		
		nb_byte=0;
		while(data_to_transfer != 0)        //!< Send data until necessary
		{
			if(nb_byte++==EP_CONTROL_LENGTH) //!< Check endpoint 0 size
				break;         
			
			Usb_write_PGM_byte(pbuffer++);          
			data_to_transfer --;	//decrements the number of bytes to transmit.
		}
		
		if (Is_usb_nak_out_sent())
			break;
		else
			Usb_send_control_in();
	}
	
	if((zlp == TRUE) && (!Is_usb_nak_out_sent()))
	{
		while(!Is_usb_read_control_enabled());
		Usb_send_control_in();
	}
	
	while (!(Is_usb_nak_out_sent()));
	Usb_ack_nak_out();
	Usb_ack_control_out();
	return TRUE;
}

//! This function manages the GET CONFIGURATION request. The current
//! configuration number is returned.
//!
void usb_get_configuration(void)
{
	Usb_ack_receive_setup();
	
	Usb_write_byte(usb_configuration_nb);
	Usb_ack_in_ready();
	
	while( !Is_usb_receive_out() );
	Usb_ack_receive_out();
}

//! This function manages the GET STATUS request. The device, interface or
//! endpoint status is returned.
//!
Bool usb_get_status( U8 bmRequestType )
{
	U8 wIndex;
	U8 dummy;
	
	dummy    = Usb_read_byte();                 //!< dummy read
	dummy    = Usb_read_byte();                 //!< dummy read
	wIndex   = Usb_read_byte();
	
	switch(bmRequestType)
	{
	case USB_SETUP_GET_STAND_DEVICE:
		Usb_ack_receive_setup();
		Usb_write_byte(device_status);
		break;
		
	case USB_SETUP_GET_STAND_INTERFACE:
		Usb_ack_receive_setup();
		Usb_write_byte(0);      // Reserved - always 0
		break;
		
	case USB_SETUP_GET_STAND_ENDPOINT:
		Usb_ack_receive_setup();
		wIndex = wIndex & MSK_EP_DIR;
		Usb_write_byte( endpoint_status[wIndex] );
		break;
		
	default:
		return FALSE;
	}
	Usb_write_byte(0);
	
	Usb_send_control_in();
	while( !Is_usb_receive_out() );
	Usb_ack_receive_out();
	return TRUE;
}

//! This function manages the SET FEATURE request. The USB test modes are
//! supported by this function.
//!
Bool usb_set_feature( U8 bmRequestType )
{
	U8 wValue;
	U8 wIndex;
	U8 dummy;
	
	switch (bmRequestType)
	{
	case USB_SETUP_SET_STAND_DEVICE:
		wValue = Usb_read_byte();
		switch (wValue)
		{
		case USB_REMOTE_WAKEUP:
			if ((wValue != FEATURE_DEVICE_REMOTE_WAKEUP)
				||  (USB_REMOTE_WAKEUP_FEATURE != ENABLED))
				return FALSE;              // Invalid request
			device_status |= USB_DEVICE_STATUS_REMOTEWAKEUP;
			remote_wakeup_feature = ENABLED;
			Usb_ack_receive_setup();
			Usb_send_control_in();
			break;
			
		default:
			return FALSE;                 // Unknow request
		}
		break;
		
	case USB_SETUP_SET_STAND_INTERFACE:
		return FALSE;                    // Unknow request
		
	case USB_SETUP_SET_STAND_ENDPOINT:
		wValue   = Usb_read_byte();
		dummy    = Usb_read_byte();                //!< dummy read
		if (wValue != FEATURE_ENDPOINT_HALT)
			return FALSE;                 // Unknow request
		wIndex = (Usb_read_byte() & MSK_EP_DIR);
		if (wIndex == EP_CONTROL)
		{
			Usb_enable_stall_handshake();
			Usb_ack_receive_setup();
		}
		Usb_select_endpoint(wIndex);
		if( !Is_usb_endpoint_enabled())
		{
			Usb_select_endpoint(EP_CONTROL);
			return FALSE;              // Invalid request
		}
		Usb_enable_stall_handshake();
		Usb_select_endpoint(EP_CONTROL);
		endpoint_status[wIndex] = 0x01;
		Usb_ack_receive_setup();
		Usb_send_control_in();
		break;
		
	default:
		return FALSE;                    // Unknow request
	}
	return TRUE;
}

//! This function manages the CLEAR FEATURE request.
//!
Bool usb_clear_feature( U8 bmRequestType )
{
	U8 wValue;
	U8 wIndex;
	U8 dummy;
	
	switch (bmRequestType)
	{
	case  USB_SETUP_SET_STAND_DEVICE:
		wValue = Usb_read_byte();
		if ((wValue != FEATURE_DEVICE_REMOTE_WAKEUP) || (USB_REMOTE_WAKEUP_FEATURE != ENABLED))
			return FALSE;              // Invalid request
		device_status &= ~USB_DEVICE_STATUS_REMOTEWAKEUP;
		remote_wakeup_feature = DISABLED;
		Usb_ack_receive_setup();
		Usb_send_control_in();
		break;
		
	case USB_SETUP_SET_STAND_INTERFACE:
		return FALSE;                    // Unknow request
		
	case USB_SETUP_SET_STAND_ENDPOINT:
		wValue = Usb_read_byte();
		dummy  = Usb_read_byte();
		if (wValue != FEATURE_ENDPOINT_HALT)
			return FALSE;                 // Unknow request
		wIndex = (Usb_read_byte() & MSK_EP_DIR);
		Usb_select_endpoint(wIndex);
		if( !Is_usb_endpoint_enabled())
		{
			Usb_select_endpoint(EP_CONTROL);
			return FALSE;              // Invalid request
		} 
		if(wIndex != EP_CONTROL)
		{
			Usb_disable_stall_handshake();
			Usb_reset_endpoint(wIndex);
			Usb_reset_data_toggle();
		}
		Usb_select_endpoint(EP_CONTROL);
		endpoint_status[wIndex] = 0x00;
		Usb_ack_receive_setup();
		Usb_send_control_in();
		break;
		
	default:
		return FALSE;                    // Unknow request
	}
	return TRUE;
}

//! This function manages the SETUP_GET_INTERFACE request.
//!
Bool usb_get_interface (void)
{
	U16   wInterface;
	U8    wValue_msb;
	U8    wValue_lsb;
	
	// Read wValue
	wValue_lsb = Usb_read_byte();
	wValue_msb = Usb_read_byte();
	// wValue = Alternate Setting
	// wIndex = Interface
	LSB(wInterface)=Usb_read_byte();
	MSB(wInterface)=Usb_read_byte();
	if( (0!=wValue_msb) || (0!=wValue_lsb) )
		return FALSE;
	Usb_ack_receive_setup();
	
	Usb_write_byte( usb_user_interface_get(wInterface) );
	Usb_send_control_in();
	
	while( !Is_usb_receive_out() );
	Usb_ack_receive_out();
	return TRUE;
}

//! This function manages the SETUP_SET_INTERFACE request.
//!
Bool usb_set_interface (void)
{
	U16   wInterface;
	U8    wValue_msb;
	U8    wValue_lsb;
	
	// Read wValue
	wValue_lsb = Usb_read_byte();
	wValue_msb = Usb_read_byte();
	// wValue = Alternate Setting
	// wIndex = Interface
	LSB(wInterface)=Usb_read_byte();
	MSB(wInterface)=Usb_read_byte();
	if( 0!=wValue_msb )
		return FALSE;
	Usb_ack_receive_setup();
	
	usb_user_interface_reset(wInterface, wValue_lsb);
	Usb_select_endpoint(EP_CONTROL);
	
	Usb_send_control_in();
	while(!Is_usb_in_ready());
	return TRUE;
}

//! This function manages the remote wake up generation
//!
void usb_generate_remote_wakeup(void)
{
	if(Is_pll_ready()==FALSE)
	{
		Pll_start_auto();
		Wait_pll_ready();
	}
	Usb_unfreeze_clock();
	if (remote_wakeup_feature == ENABLED)
	{
		Usb_initiate_remote_wake_up();
		remote_wakeup_feature = DISABLED;
	}
}  
