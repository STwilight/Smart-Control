#include "config.h"
#include "power_drv.h"
#include "usb_task.h"
#include "usb_device_task.h"
#include "usb_drv.h"

void main(void)
{
	DDRB = 0;
	DDRC = 0x14;
	PORTC = 0x10;
	CLKPR=(1<<CLKPCE);
	CLKPR=0;
	usb_device_task_init();
	for(;;) usb_device_task();
}
