#include "config.h"
#include "conf_usb.h"
#include "usb_task.h"
#include "usb_drv.h"
#include "usb_descriptors.h"
#include "power_drv.h"
#include "pll_drv.h"
#include "usb_device_task.h"

#ifndef LOG_STR_CODE
#define LOG_STR_CODE(str)
#else
U8 code log_device_disconnect[]="Device Disconnected";
U8 code log_id_change[]="Pin Id Change";
#endif

//! Public : U16 g_usb_event
//! usb_connected is used to store USB events detected upon
//! USB general interrupt subroutine
//! Its value is managed by the following macros (See usb_task.h file)
//! Usb_send_event(x)
//! Usb_ack_event(x)
//! Usb_clear_all_event()
//! Is_usb_event(x)
//! Is_not_usb_event(x)
volatile U16 g_usb_event=0;

//! Public : (bit) usb_connected
//! usb_connected is set to TRUE when VBUS has been detected
//! usb_connected is set to FALSE otherwise
extern bit usb_connected;

//! Public : (U8) usb_configuration_nb
//! Store the number of the USB configuration used by the USB device
//! when its value is different from zero, it means the device mode is enumerated
extern U8 usb_configuration_nb;

//! Public : (U8) remote_wakeup_feature
//! Store a host request for remote wake up (set feature received)
extern U8 remote_wakeup_feature;

//! This function is called each time a USB interrupt occurs.
//! The following USB DEVICE events are taken in charge:
//! - VBus On / Off
//! - Start Of Frame
//! - Suspend
//! - Wake-Up
//! - Resume
//! - Reset
//! - Start of frame
//!
//! The following USB HOST events are taken in charge:
//! - Device connection
//! - Device Disconnection
//! - Start Of Frame
//! - ID pin change
//! - SOF (or Keep alive in low speed) sent
//! - Wake up on USB line detected
//!
//! For each event, the user can launch an action by completing
//! the associate define (See conf_usb.h file to add action upon events)
//!
//! Note: Only interrupts events that are enabled are processed
#pragma vector = USB_General_vect
__interrupt void usb_general_interrupt()
{
	// ---------- DEVICE events management -----------------------------------
	// - Device start of frame received
	if (Is_usb_sof() && Is_sof_interrupt_enabled())
	{
		Usb_ack_sof();
		Usb_sof_action();
	}
	// - USB bus reset detection
	if (Is_usb_reset()&& Is_reset_interrupt_enabled())
	{
		Usb_ack_reset();
		usb_init_device();
		Usb_reset_action();
		Usb_send_event(EVT_USB_RESET);
	}
}





