#ifndef _CONF_USB_H_
#define _CONF_USB_H_

#include "usb_commun.h"

#define NB_ENDPOINTS		0  // number of endpoints in the application
//#define EP_IN				1
//#define EP_OUT			2

#define Usb_unicode(a)         ((U16)(a))
#define USB_REMOTE_WAKEUP_FEATURE   DISABLE

   //! @defgroup device_cst_actions USB device custom actions
   //!
   //! @{
   // write here the action to associate to each USB event
   // be carefull not to waste time in order not disturbing the functions
#define Usb_sof_action()
#define Usb_wake_up_action()
#define Usb_resume_action()
#define Usb_suspend_action()
#define Usb_reset_action()
#define Usb_vbus_on_action()
#define Usb_vbus_off_action()
#define Usb_set_configuration_action()

#endif // _CONF_USB_H_
