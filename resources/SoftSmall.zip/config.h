#ifndef _CONFIG_H_
#define _CONFIG_H_

#define ENABLE_BIT_DEFINITIONS
#define __AT90USB162__
#include <ioavr.h>                     // Use IAR-AVR library
#include "compiler.h"

//! CPU core frequency in kHz
#define FOSC 8000

#endif // _CONFIG_H_

