These are the 3rd Party Externals required for building the Test GUI
for HIDAPI on Windows. The test GUI depends on Fox Tooolkit. The
source code for these files is located in the Sources folder.

This folder should be put at the same level as the HIDAPI folder
itself in order to make the build work on Windows without
modification.

These files are not required for building on non-Windows platforms.

For more information, read README.txt in the HIDAPI source
distribution.

Alan Ott
Signal 11 Software
2010-07-22
