#ifndef IRMANAGER_H_INCLUDED
#define IRMANAGER_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>
#include "datatypes.h"

#define IRB_ONOFF		0
#define IRB_SOUNDONOFF 	1
#define IRB_SCREENCAP 	2
#define IRB_MOODLAMP 	3
#define IRB_PLUS 		4
#define IRB_MINUS 		5

#define IRB_COUNT		6

extern void IRManager_init(void);
extern void IRManager_clearCmdBuffer(void);
extern bool IRManager_haveValidCommand(void);
extern void IRManager_update(void);
extern void IRManager_setupButtons(void);
extern uint8_t IRManager_getButtonId( void);


#endif /* IRMANAGER_H_INCLUDED */
