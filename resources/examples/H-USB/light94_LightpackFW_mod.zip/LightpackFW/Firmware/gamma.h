#ifndef GAMMA_H_INCLUDED
#define GAMMA_H_INCLUDED

#include <stdint.h>
#include <avr/pgmspace.h>

extern const uint8_t PROGMEM gammaTable[5][256];

#endif
