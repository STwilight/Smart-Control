#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include "iodefs.h"
#include "IRManager.h"
#include "LedManager.h"
#include "stx.h"

#define IR_FRAME_US     560
#define IR_BAUD_SETTING ((((( F_CPU * 1LL * IR_FRAME_US /  16000000 ) * 2 ) + 1 ) >> 1 ) - 1)

#define CMDBYTES    12

uint8_t s_CMDBuffer[ CMDBYTES ];
uint8_t s_cmdBufferIndex = 0;

uint16_t EEMEM s_commands[ IRB_COUNT * 2 ];

//================================================
//================================================
void IRManager_init()
{
    // USART1 initialization
    // Communication Parameters: 7 Data, 1 Stop, No Parity
    // USART1 Receiver: On
    // USART1 Transmitter: Off
    // USART1 Mode: Asynchronous
    // USART1 Baud Rate: 1000000 / 560ms
    UCSR1A=0x00;
    UCSR1B=0x10;
    UCSR1C=0x04;
    UBRR1H=IR_BAUD_SETTING >> 8;
    UBRR1L=IR_BAUD_SETTING & 0xff;
}

//================================================
//================================================
uint8_t readCMDBuffer( uint8_t _index )
{
    if ( _index >= CMDBYTES )
    {
        _index -= CMDBYTES;
    }

    return s_CMDBuffer[ _index ];
}

//================================================
//================================================
void IRManager_clearCmdBuffer()
{
    uint8_t i;

    for ( i = 0; i < CMDBYTES; i++ )
    {
        s_CMDBuffer[ i ] = 0xff;
    }
}

//================================================
//================================================
bool IRManager_haveValidCommand()
{
    if (
            ( readCMDBuffer( s_cmdBufferIndex ) == 0 ) &&
            ( readCMDBuffer( s_cmdBufferIndex + 1 ) == 0x55 ) &&
            ( readCMDBuffer( s_cmdBufferIndex + 2 ) == 0xd5 ) &&
            ( readCMDBuffer( s_cmdBufferIndex + 3 ) == 0x77 ) &&
            ( readCMDBuffer( s_cmdBufferIndex + 4 ) == 0x77 ) &&
            ( readCMDBuffer( s_cmdBufferIndex + 5 ) == 0x57 )
    )
    {
        return true;
    }

    return false;
}

//================================================
//================================================
uint32_t calcCommandCRC( uint8_t _index )
{
    uint32_t crc;
    uint8_t i,j;

    crc = 0;

    for ( i = 0 ; i < CMDBYTES; i++ )
    {
      crc = crc ^ readCMDBuffer( _index + i );
      for ( j = 0; j < 8; j++ )
      {
         if (crc & 1)
            crc = (crc>>1) ^ 0xEDB88320;
         else
            crc = crc >>1 ;
      }
    }
   return crc ;
}

//================================================
//================================================
uint32_t getButtonCode( uint8_t id )
{
	uint32_t code;

	code = eeprom_read_word( &s_commands[ id * 2 + 1 ] );
	code <<= 16;
	code |= eeprom_read_word( &s_commands[ id * 2 ] );

	return code;
}

//================================================
//================================================
void storeButtonCode( uint8_t id, uint32_t code )
{
	eeprom_write_word( &s_commands[ id * 2 ], code & 0xffff );
	eeprom_write_word( &s_commands[ id * 2 + 1 ], code >> 16 );
}

//================================================
//================================================
void printCommand(void)
{
    for ( uint8_t i = 0 ; i < CMDBYTES; i++ )
    {
      stx_uint8( readCMDBuffer( s_cmdBufferIndex + i ) );
      stx_string_P( PSTR( " " ) );
    }

	stx_string_P( PSTR( "\n" ) );

}

//================================================
//================================================
void setupButton( uint8_t id )
{
	IRManager_init();
	LedManager_FlashLedsRed();
	LedManager_LitLeds( id + 1 );

	stx_uint8( id );
	stx_string_P( PSTR( "\n" ) );

	while ( 1 )
	{
		wdt_reset();
		IRManager_update();

		if ( IRManager_haveValidCommand() )
		{
			uint32_t command = calcCommandCRC( s_cmdBufferIndex);

			stx_uint16( command );
			stx_string_P( PSTR( " " ) );
			printCommand();

			IRManager_clearCmdBuffer();

			if ( command == getButtonCode( id ) )
			{
				break;
			}

			stx_string_P( PSTR( "retry\n" ) );

			storeButtonCode( id, command );
			LedManager_FlashLedsRed();
			LedManager_LitLeds( id + 1 );
		}
	}
}

//================================================
//================================================
void IRManager_setupButtons(void)
{
	asm ("cli");

	setupButton( IRB_ONOFF );
	setupButton( IRB_SOUNDONOFF );
	setupButton( IRB_SCREENCAP );
	setupButton( IRB_MOODLAMP );
	setupButton( IRB_PLUS );
	setupButton( IRB_MINUS );

	asm ("sei");

}

//================================================
//================================================
void IRManager_update()
{
    if  ( (UCSR1A & (1<<RXC1)) )
    {
        //has data
        if ( (UCSR1A & (1<<FE1)) )
        {
            //stop bit was 0
            s_CMDBuffer[ s_cmdBufferIndex ] = UDR1;
        }
        else
        {
            s_CMDBuffer[ s_cmdBufferIndex ] = UDR1 | 0x80;
        }

        s_cmdBufferIndex++;
        if ( s_cmdBufferIndex == CMDBYTES )
        {
            s_cmdBufferIndex = 0;
        }
    }

}

//========================================================
//========================================================
uint8_t IRManager_getButtonId( void)
{
	uint32_t command = calcCommandCRC( s_cmdBufferIndex);

	for ( uint8_t i = 0; i < IRB_COUNT; i++ )
	{
		if ( command == getButtonCode( i ) )
		{
			return i;
		}
	}

	return 255;
}
