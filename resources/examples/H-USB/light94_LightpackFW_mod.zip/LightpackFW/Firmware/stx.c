/**
 Simple TX - ������� ������� ����������� �������� �� ��������� RS-232

 ����������� stx.h

 $Rev: 71 $
*/

#include "stx.h"
#include <avr/io.h>
#include <avr/pgmspace.h>

void stx_char(unsigned char value)
{
    volatile unsigned char i = 1;
        //#asm("cli")

    stx_pin_off();                                         // ��������� ���
    stx_delay(0);
    while(i){
      if(value & i){
        stx_pin_on();
      }else{
        stx_pin_off();
      }
      i <<= 1;
      stx_delay(20);
    }
    stx_pin_on();                                          // ������ ��������� ����
    stx_delay(40);
     //#asm("sei")
  }
  
//=====================================================
//=====================================================
void stx_string_P( const char* _msg )
{
    while ( 1 )
    {
    	char c = pgm_read_byte(_msg++);
    	if ( c == 0 )
    	{
    		break;
    	}
        stx_char( c );
    }
}

//=====================================================
//=====================================================
void stx_string( const char* _msg )
{
    while ( *_msg != 0 )
    {
        stx_char( *_msg++);
    }
}

static const char* hex = "0123456789ABCDEF";


//=====================================================
//=====================================================
void stx_uint16( uint16_t _value )
{
    stx_char( hex [ ( ( _value >> 12 ) & 0xf ) ] );
    stx_char( hex [ ( ( _value >> 8 ) & 0xf ) ] );
    stx_char( hex [ ( ( _value >> 4 ) & 0xf ) ] );
    stx_char( hex [ ( _value & 0xf ) ] );

}

//=====================================================
//=====================================================
void stx_uint8( uint8_t _value )
{
    stx_char( hex [ ( ( _value >> 4 ) & 0xf ) ] );
    stx_char( hex [ ( _value & 0xf ) ] );

}
