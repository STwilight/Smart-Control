ATMEL 2007

Readme file to compile AT90USB162 firmware demonstration with AVRGCC (winavr 20070525 revision). Since this version, AT90USB162 is supported by AVRGCC.

If you are using the WinAVR project file (.aps), your project must be placed in the C:\Atmel directory.
  for example, the USB HID WinAVR project file must be at directory :
	--> C:\Atmel\at90usb162-hidgen-1_0_1\at90usb162\demo\hid_gen\gcc
     
