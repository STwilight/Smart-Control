//! @file config.h,v
//!
//! Copyright (c) 2006 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! This file contains the system configuration definition
//!
//! @version 1.1 at90usb162-hidgen-1_0_1 $Id: config.h,v 1.1 2006/12/12 09:48:04 arobert Exp $
//!
//! @todo
//! @bug

#ifndef _CONFIG_H_
#define _CONFIG_H_

//! @defgroup global_config Application configuration
//! @{

//_____ I N C L U D E S ____________________________________________________


#ifdef AVRGCC
   #define __AVR_AT90USB162__
#endif

#include "lib_mcu\compiler.h" //!< Compiler definitions


#ifdef AVRGCC
   #include <avr/io.h>
#else
   #include "lib_mcu\mcu.h" //!< Register declaration
#endif

#include "conf/conf_scheduler.h" //!< Scheduler tasks declaration

#define  STK525   0
#define  USBKEY   1
#define  SPIDER     2
#define  WRD_PHLPS  3


//! To include proper target hardware definitions, select
//! target board (USBKEY or STK525)
#define TARGET_BOARD STK526

#if (TARGET_BOARD==USBKEY)
   //! @warning for #define USBKEY_HAS_321_DF, only first prototypes versions have AT45DB321C memories
   //! should be undefined for std series
   #define USBKEY_HAS_321_DF
   #include "lib_board\usb_key\usb_key.h"
#elif (TARGET_BOARD==STK526)
   #include "lib_board\stk_526\stk_526.h"
#elif (TARGET_BOARD==SPIDER)
   #include "lib_board\spider\spider_drv.h"
#elif (TARGET_BOARD==WRD_PHLPS)
   #include "lib_board\wired_philips\mouse_wired_philips_drv.h"
   #include "lib_mcu/quickstart/at90usb162_quickstart_drv.h"
#else
   #error TARGET_BOARD must be defined somewhere
#endif


//! CPU core frequency in kHz
#define FOSC 8000


// -------- END Generic Configuration -------------------------------------

// UART Sample configuration, if we have one ... __________________________
#define BAUDRATE        57600
#define USE_UART2

#define uart_putchar putchar
#define r_uart_ptchar int
#define p_uart_ptchar int



//! @}

#endif // _CONFIG_H_

