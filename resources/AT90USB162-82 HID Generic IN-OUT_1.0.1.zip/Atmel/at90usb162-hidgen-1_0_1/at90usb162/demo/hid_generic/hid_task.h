/**
 * @file hid_task.h,v
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file contains the function declarations
 *
 * @version 1.1 at90usb162-hidgen-1_0_1 $Id: hid_task.h,v 1.1 2006/12/12 09:48:03 arobert Exp $
 *
 * @todo
 * @bug
 */

#ifndef _HID_TASK_H_
#define _HID_TASK_H_

//_____ I N C L U D E S ____________________________________________________


#include "config.h"

//_____ M A C R O S ________________________________________________________



//_____ D E C L A R A T I O N S ____________________________________________




#endif /* _HID_TASK_H_ */

